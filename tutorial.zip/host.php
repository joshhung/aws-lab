<?php
  echo gethostname();
?>
