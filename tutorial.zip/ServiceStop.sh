#!/bin/bash
service apache2 stop
